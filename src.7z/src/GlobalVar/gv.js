/**
 * Created by CPU02326_Local on 7/31/2018.
 */

/* Building Move */
gv.buildingMove =
{
    currentRow : null,
    currentCol : null,
}

gv.reloaded = false;