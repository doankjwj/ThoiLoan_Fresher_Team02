/**
 * Created by KienVN on 9/29/2017.
 */

var res = res||{};
res.base = {};
//FONT
res.font
//IMG
res.base.img_btn_disable =  "Default/Button_Disable.png";
res.base.img_btn_press = "Default/Button_Disable.png";
res.base.img_btn_normal = "Default/Button_Normal.png";

