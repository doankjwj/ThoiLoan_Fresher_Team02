/**
 * Created by CPU02326_Local on 8/15/2018.
 */
var gvGUI = gvGUI || {};
gvGUI.layerClanChat = null;
gvGUI.popUpDonateTroop = null;
gvGUI.TAG_BUTTON_CLOSE = 23115;
gvGUI.popUpToCoin = null;
