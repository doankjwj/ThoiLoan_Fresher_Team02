/**
 * Created by CPU02326_Local on 8/17/2018.
 */
var onUpdateContentDonate = function(){
    var TAG_ITEM_0 = null;
    var TAG_ITEM_1 = null;
    var TAG_ITEM_2 = null;
    var TAG_ITEM_3 = null;
    cc.log("Update Content For PopUp Donate");


    var armyCamp = cf.user._buildingList[gv.orderInUserBuildingList.armyCamp_1][0];
    cc.log("Troop Length: " + armyCamp._troopList.length);
    cc.log("Troop Length: " + armyCamp._troopList.length);
    if (!gvGUI.popUpDonateTroop.getChildByTag(TAG_ITEM_0)){

    };
    if (!gvGUI.popUpDonateTroop.getChildByTag(TAG_ITEM_0)){

    };
    if (!gvGUI.popUpDonateTroop.getChildByTag(TAG_ITEM_0)){

    };
    if (!gvGUI.popUpDonateTroop.getChildByTag(TAG_ITEM_0)){

    }
}