var MyClan = ClanDetail.extend({

    ctor: function(){
        this._super();
    },

    onAppear: function(){

    },

});