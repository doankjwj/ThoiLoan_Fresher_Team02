/**
 * Created by CPU02326_Local on 8/15/2018.
 */
var ClanChat = cc.Layer.extend({
    _bg: null,

    ctor: function(){
        this._super();
        this.setAnchorPoint(0, 0);
    }
})