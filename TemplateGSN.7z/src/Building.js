var building = cc.Sprite.extend({
    ctor: function(src)
    {
        this._super(src);
        this.anchorX = 0.5;
        this.anchorY = 0.5;
    }
})

